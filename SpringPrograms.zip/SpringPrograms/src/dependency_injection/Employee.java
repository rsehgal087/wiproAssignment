package dependency_injection;

public class Employee {
	private int empID; 
	private String name;
	private String dept;
	private Department department;
	
	public int getempID() {
		return empID;
	}
	public void setempID(int empID) {
		this.empID = empID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	
	public void Display_Employee_Info() {
		System.out.println("Employee id : "+empID);
		System.out.println("Name : "+name);
		System.out.println("Dept type : "+dept);
		department.DisplayDepartment(dept);
		
	}
	
	

}
