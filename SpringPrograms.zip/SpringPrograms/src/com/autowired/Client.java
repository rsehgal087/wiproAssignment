package com.autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Client {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("BeansAutowired.xml");
		
		Employee employee_object = (Employee)context.getBean("employee");
		employee_object.Display_Employee_Info();
	}

}


