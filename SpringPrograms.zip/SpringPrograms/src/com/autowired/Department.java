package com.autowired;
public class Department {
	public void DisplayDepartment(String emp_type) {
		
		if(emp_type.equals("HR"))
			System.out.println("HR Department, Role: Recruitment, Employee Benefits");
		else if(emp_type.equals("Admin"))
			System.out.println("Admin Department, Role: Transportation to employees, food coupons");
		else if(emp_type.equals("Technology"))
			System.out.println("Technology Department, Role: Research and Development, training");
	}

}
