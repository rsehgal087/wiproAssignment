
import org.springframework.beans.factory.annotation.Required;
public class Employee {
	public int empld; 
	public String name; 
	public String designation;
	public String dept;
	
	public int getEmpld() {
		return empld;
	}
	@Required
	public void setEmpld(int empld) {
		this.empld = empld;
	}
	public String getName() {
		return name;
	}
	@Required
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	@Required
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDept() {
		return dept;
	}
	@Required
	public void setDept(String dept) {
		this.dept = dept;
	}
	

}
