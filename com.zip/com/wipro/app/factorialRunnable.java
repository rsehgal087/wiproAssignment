package com.wipro.app;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class factorialRunnable {
	public static void main(String[] args) {
		int num= 4;
		
		 Runnable task = new Runnable() {
	            @Override
	            public void run() {
	                int fact = 1;
	                for (int i = 1; i <= num; i++) {
	                    fact *= i;
	                }
	                System.out.println("Factorial of " + num + " is: " + fact);
	            }
	        };

	        ExecutorService executor = Executors.newSingleThreadExecutor();
	        executor.submit(task);
	        executor.shutdown();
	   
	}

}
